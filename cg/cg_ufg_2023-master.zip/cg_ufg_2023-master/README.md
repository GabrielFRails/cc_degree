# Computação Gráfica - UFG 2023.2

Copyright (c) Universidade Federal de Goiás \
Copyright (c) 2023 Gabriel Freitas gabriel.estudy.reis@gmail.com

## Install requirements

### os config (Linux)

```
% sudo apt-get update 
% apt-get upgrade 
% sudo apt-get install build-essential
```

if the command don't work, try to run in "sudo su" terminal

### install GLUT

```
% sudo apt-get install freeglut3 freeglut3-dev
```

### Running our code

Each directory have a Makefile with targets to make your life easier, \
i highly recommend you to read, enjoy, and have fun.
