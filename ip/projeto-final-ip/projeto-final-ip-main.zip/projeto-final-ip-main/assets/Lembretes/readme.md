Essa pasta tem a finalidade de guardar os arquivos com os lembretes dos usuários separados
por ano.